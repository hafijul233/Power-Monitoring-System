<?php
    require 'config/config.php';
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=pages/index.php">
<title><?php echo $programName; ?></title>
<script language="javascript">
    window.location.href = "pages/login.php"
</script>
</head>
<body>
Go to <a href="pages/index.php">Dashboard</a>
</body>
</html>
